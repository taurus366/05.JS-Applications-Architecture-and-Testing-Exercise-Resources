const {expect, assert} = require('chai')
const {chromium} = require('playwright-chromium');
// const {} = require('mocha');
let browser, page;

describe('E2E tests', function () {
    this.timeout(60000)
    before(async () => {
        browser = await chromium.launch({headless: false, slowMo: 600})
    });
    after(async () => {
        await browser.close();
    });
    beforeEach(async () => {
        page = await browser.newPage();
    });
    afterEach(async () => {
        await page.close();
    });

    it('Testing: load books', async () => {
        await page.goto('http://localhost:3000/');
        await page.click('text=LOAD ALL BOOKS');
        await page.waitForSelector('td');


        const text = await page.$$eval("tbody >> tr >> td:first-child",tr => tr.map(tr => tr.textContent.trim()));
        console.log(text)
        expect(text[0]).to.be.equal('Harry Potter and the Philosopher\'s Stone');
        expect(text[1]).to.be.equal('C# Fundamentals');


    });



});


